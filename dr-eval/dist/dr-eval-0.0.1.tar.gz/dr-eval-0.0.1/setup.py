from setuptools import setup, find_packages

setup(
    name='dr-eval',
    version='0.0.1',
    packages=find_packages(),
    description='Dr. Eval',
    long_description='Upcoming LLM test framework',
    author='lumpenspace',
    author_email='lumpenspace@gmail.com',
    url='https://github.com/lumpenspace/dr-eval',
    install_requires=[],
)
